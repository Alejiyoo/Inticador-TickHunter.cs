﻿using System.Windows.Input;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class KeyboardManager
    {
        public static bool IsCtrlKeyDown()
        {
            bool returnFlag = false;

            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public static bool IsShiftKeyDown()
        {
            bool returnFlag = false;

            if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
            {
                returnFlag = true;
            }

            return returnFlag;
        }
    }
}
