﻿using System;
using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealMultiCycleCache
    {
        private Dictionary<string, DateTime> multiCycleCache = new Dictionary<string, DateTime>();
        private readonly object MultiCycleCacheLock = new object();
        private const int AutoExpireSeconds = 10;

        private DateTime GenerateExpirationTime()
        {
            return DateTime.Now.AddSeconds(AutoExpireSeconds);
        }
        public int Count
        {
            get 
            { 
                lock (MultiCycleCacheLock)
                {
                    return multiCycleCache.Count; 
                }
            }
        }
        public bool HasElements(bool logExpiredElements = false)
        {
            bool hasElementsFlag = false;

            // Use Count property which is thread-safe
            hasElementsFlag = (this.Count != 0);

            if (hasElementsFlag)
            {
                ClearExpiredElements(logExpiredElements);
                // Re-check after clearing expired elements
                hasElementsFlag = (this.Count != 0);
            }

            return hasElementsFlag;
        }

        public bool ContainsKey(string uniqueId)
        {
            bool returnFlag = false;

            lock (MultiCycleCacheLock)
            {
                returnFlag = multiCycleCache.ContainsKey(uniqueId);
            }

            return returnFlag;
        }
        public bool TouchUniqueId(string uniqueId)
        {
            bool returnFlag = false;

            lock (MultiCycleCacheLock)
            {
                if (multiCycleCache.ContainsKey(uniqueId))
                {
                    DateTime expireDateTime = GenerateExpirationTime();
                    if (multiCycleCache[uniqueId] != null)
                    {
                        returnFlag = true;
                        multiCycleCache[uniqueId] = expireDateTime;
                    }
                }
            }

            return returnFlag;
        }

        public bool RegisterUniqueId(string uniqueId)
        {
            bool returnFlag = false;

            lock (MultiCycleCacheLock)
            {
                if (!multiCycleCache.ContainsKey(uniqueId))
                {
                    DateTime expireDateTime = GenerateExpirationTime();
                    multiCycleCache.Add(uniqueId, expireDateTime);
                    returnFlag = true;
                }
            }

            return returnFlag;
        }

        public void DeregisterUniqueId(string uniqueId)
        {
            lock (MultiCycleCacheLock)
            {
                multiCycleCache.Remove(uniqueId);
            }
        }

        public bool TryDeregisterUniqueId(string uniqueId)
        {
            bool removed = false;
            lock (MultiCycleCacheLock)
            {
                if (multiCycleCache.ContainsKey(uniqueId))
                {
                    multiCycleCache.Remove(uniqueId);
                    removed = true;
                }
            }
            return removed;
        }

        public void ClearExpiredElements(bool logExpiredElements)
        {
            lock (MultiCycleCacheLock)
            {
                RealLogger logger = null;

                List<string> expiredElements = new List<string>();
                DateTime currentTime = DateTime.Now;

                foreach (KeyValuePair<string, DateTime> element in multiCycleCache)
                {
                    if (element.Value <= currentTime)
                    {
                        expiredElements.Add(element.Key);
                    }
                }

                foreach (string keyName in expiredElements)
                {
                    if (logExpiredElements)
                    {
                        if (logger == null) logger = new RealLogger("InternalLogger");

                        logger.PrintOutput("MultiCycleCache keyName=" + keyName + " has expired and was removed");
                    }

                    multiCycleCache.Remove(keyName);
                }
            }
        }

        public void Clear()
        {
            lock (MultiCycleCacheLock)
            {
                multiCycleCache.Clear();
            }
        }
    }
}
