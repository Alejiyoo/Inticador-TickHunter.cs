﻿using NinjaTrader.Cbi;
using System;
using System.Threading;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealOrder
    {
        private const int StateHasChanged = 1;
        private const int StateHasNotChanged = 0;
        private int stateChangeStatus = StateHasChanged;

        private long orderId = 0;
        private string exchangeOrderId = "";
        private string name = "";
        private OrderType orderType = OrderType.Unknown;
        private double averagePrice = 0;
        private double limitPrice = 0;
        private double limitPriceChanged = 0;
        private double stopPrice = 0;
        private double stopPriceChanged = 0;
        private OrderState orderState = OrderState.Unknown;
        private OrderAction orderAction = OrderAction.Buy;
        private Instrument instrument = null;
        private int quantity = 0;
        private int quantityChanged = 0;
        private int quantityFilled = 0;
        private Account account = null;

        public RealOrder()
        {

        }

        public string ExchangeOrderId
        {
            get
            {
                return exchangeOrderId;
            }
            set
            {
                ChangeStateFlag();
                exchangeOrderId = value;
            }
        }

        public long OrderId
        {
            get
            {
                return orderId;
            }
            set
            {
                ChangeStateFlag();
                orderId = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                ChangeStateFlag();
                name = value;
            }
        }

        public bool IsValid
        {
            get
            {
                if (orderType != OrderType.Unknown)
                    return true;
                else
                    return false;
            }
        }

        public bool IsLimit
        {
            get
            {
                return (this.OrderType == OrderType.Limit);
            }
        }

        public bool IsStopMarket
        {
            get
            {
                return (this.OrderType == OrderType.StopMarket);
            }
        }

        public bool IsMarket
        {
            get
            {
                return (this.OrderType == OrderType.Market);
            }
        }

        public Account Account
        {
            get
            {
                return account;
            }
            set
            {
                ChangeStateFlag();
                account = value;
            }
        }

        public OrderAction OrderAction
        {
            get
            {
                return orderAction;
            }
            set
            {
                ChangeStateFlag();
                orderAction = value;
            }
        }

        public OrderType OrderType
        {
            get
            {
                return orderType;
            }
            set
            {
                ChangeStateFlag();
                orderType = value;
            }
        }

        public OrderState OrderState
        {
            get
            {
                return orderState;
            }
            set
            {
                ChangeStateFlag();
                orderState = value;
            }
        }

        public double AveragePrice
        {
            get
            {
                return averagePrice;
            }
            set
            {
                ChangeStateFlag();
                averagePrice = value;
            }
        }

        public double LimitPrice
        {
            get
            {
                return limitPrice;
            }
            set
            {
                ChangeStateFlag();
                limitPrice = value;
            }
        }

        public double LimitPriceChanged
        {
            get
            {
                return limitPriceChanged;
            }
            set
            {
                ChangeStateFlag();
                limitPriceChanged = value;
            }
        }

        public double StopPrice
        {
            get
            {
                return stopPrice;
            }
            set
            {
                ChangeStateFlag();
                stopPrice = value;
            }
        }

        public double StopPriceChanged
        {
            get
            {
                return stopPriceChanged;
            }
            set
            {
                ChangeStateFlag();
                stopPriceChanged = value;
            }
        }

        public Instrument Instrument
        {
            get
            {
                return instrument;
            }
            set
            {
                ChangeStateFlag();
                instrument = value;
            }
        }

        public int Quantity
        {
            get
            {
                return quantity;
            }
            set
            {
                ChangeStateFlag();
                quantity = value;
            }
        }

        public int QuantityChanged
        {
            get
            {
                return quantityChanged;
            }
            set
            {
                ChangeStateFlag();
                quantityChanged = value;
            }
        }

        public int QuantityFilled
        {
            get
            {
                return quantityFilled;
            }
            set
            {
                ChangeStateFlag();
                quantityFilled = value;
            }
        }

        public int QuantityRemaining
        {
            get
            {
                return (quantity - quantityFilled);
            }
        }

        public bool HasStateChanged()
        {
            return (stateChangeStatus == StateHasChanged);
        }

        public void StoreState()
        {
            ResetStateFlag();
        }

        private void ChangeStateFlag()
        {
            Interlocked.Exchange(ref stateChangeStatus, StateHasChanged);
        }

        private void ResetStateFlag()
        {
            Interlocked.Exchange(ref stateChangeStatus, StateHasNotChanged);
        }
    }

}
