﻿using NinjaTrader.Cbi;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealPositionService
    {
        private readonly List<RealPosition> realPositions = new List<RealPosition>();
        private readonly object realPositionLock = new object();

        private DateTime GetDateTimeNow()
        {
            DateTime now = DateTime.MinValue;

            bool isUsingPlaybackConnection = (NinjaTrader.Cbi.Connection.PlaybackConnection != null);

            if (isUsingPlaybackConnection)
            {
                now = NinjaTrader.Cbi.Connection.PlaybackConnection.Now;
            }
            else
            {
                now = DateTime.Now;
            }

            return now;
        }

        public int PositionCount
        {
            get { lock (realPositionLock) { return realPositions.Count; } }
        }

        public bool IsValidPosition(RealPosition position, Instrument instrument)
        {
            bool returnFlag = false;

            if (position.Instrument.FullName == instrument.FullName && !position.IsFlat())
            {
                returnFlag = true;
            }

            return returnFlag;
        }

        public bool TryGetByIndex(int index, out RealPosition realPosition)
        {
            bool returnFlag = false;
            realPosition = null;

            lock (realPositionLock)
            {
                try
                {
                    if (index >= 0 && index < realPositions.Count)
                    {
                        realPosition = realPositions[index];
                        returnFlag = true;
                    }
                }
                catch
                {
                    //stuff exception 
                }
            }

            return returnFlag;
        }

        public bool TryGetByInstrumentFullName(string instrumentFullName, out RealPosition realPosition)
        {
            bool returnFlag = false;
            realPosition = null;

            lock (realPositionLock)
            {
                try
                {
                    RealPosition tempRealPosition;
                    // Use for loop with direct indexing instead of ElementAt - more thread-safe than foreach
                    for (int index = 0; index < realPositions.Count; index++)
                    {
                        tempRealPosition = realPositions[index];

                        if (tempRealPosition != null && tempRealPosition.Instrument != null && tempRealPosition.Instrument.FullName == instrumentFullName)
                        {
                            realPosition = tempRealPosition;
                            returnFlag = true;
                            break;
                        }
                    }
                }
                catch
                {
                    //stuff exception 
                }
            }

            return returnFlag;
        }

        public RealPosition BuildRealPosition(Account account, Instrument instrument, MarketPosition marketPosition, int quantity, double averagePrice, DateTime createDate)
        {
            RealPosition realPosition = new RealPosition();

            realPosition.Account = account;
            realPosition.Instrument = instrument;
            realPosition.MarketPosition = marketPosition;
            realPosition.Quantity = quantity;
            realPosition.AveragePrice = averagePrice;
            realPosition.CreateDate = createDate;
            realPosition.ModifyDate = createDate;


            return realPosition;
        }

        private int GetNewQuantity(RealPosition existingPosition, RealPosition newPosition)
        {
            int newQuantity = 0;

            if (existingPosition.MarketPosition == MarketPosition.Long)
            {
                if (newPosition.MarketPosition == MarketPosition.Long)
                    newQuantity = existingPosition.Quantity + newPosition.Quantity;
                else
                    newQuantity = existingPosition.Quantity - newPosition.Quantity;
            }
            else if (existingPosition.MarketPosition == MarketPosition.Short)
            {
                if (newPosition.MarketPosition == MarketPosition.Long)
                    newQuantity = existingPosition.Quantity - newPosition.Quantity;
                else
                    newQuantity = existingPosition.Quantity + newPosition.Quantity;
            }

            return newQuantity;
        }

        private MarketPosition FlipMarketPosition(MarketPosition marketPosition)
        {
            MarketPosition newMarketPosition = marketPosition;

            if (marketPosition == MarketPosition.Long)
            {
                newMarketPosition = MarketPosition.Short;
            }
            else if (marketPosition == MarketPosition.Short)
            {
                newMarketPosition = MarketPosition.Long;
            }

            return newMarketPosition;
        }

        public void AddPosition(RealPosition position)
        {
            lock (realPositionLock)
            {
                realPositions.Add(position);
            }
        }

        public void UpdatePosition(RealPosition position)
        {
            lock (realPositionLock)
            {
                RealPosition foundPosition = null;

                if (position != null && position.Instrument != null && TryGetByInstrumentFullName(position.Instrument.FullName, out foundPosition))
                {
                    bool isSameDirection = (foundPosition.MarketPosition == position.MarketPosition);
                    bool isDecreasingQuantity = (position.Quantity < foundPosition.Quantity);
                    
                    foundPosition.ModifyDate = position.ModifyDate;
                    foundPosition.Quantity = position.Quantity;
                    foundPosition.MarketPosition = position.MarketPosition;

                    // Keep the running average price when reducing position size in same direction
                    // Only update average price if position is increasing or direction has changed
                    if (!isSameDirection || !isDecreasingQuantity)
                    {
                        foundPosition.AveragePrice = position.AveragePrice;
                    }
                    // else: keep existing AveragePrice to maintain running average
                }
            }
        }

        public void RemovePosition(RealPosition position)
        {
            lock (realPositionLock)
            {
                RealPosition foundPosition = null;

                if (position != null && position.Instrument != null && TryGetByInstrumentFullName(position.Instrument.FullName, out foundPosition))
                {
                    realPositions.Remove(foundPosition);
                }
            }
        }

        public int AddOrUpdatePosition(RealPosition position)
        {
            int positionQuantity = 0;

            lock (realPositionLock)
            {
                RealPosition foundPosition = null;

                if (position != null && position.Instrument != null && TryGetByInstrumentFullName(position.Instrument.FullName, out foundPosition))
                {
                    MarketPosition newMarketPosition;
                    int newQuantity = GetNewQuantity(foundPosition, position);

                    if (newQuantity < 0)
                    {
                        newQuantity *= -1; // flip to positive number

                        newMarketPosition = FlipMarketPosition(foundPosition.MarketPosition);
                    }
                    else
                    {
                        newMarketPosition = foundPosition.MarketPosition;
                    }

                    if (newQuantity == 0)
                    {
                        realPositions.Remove(foundPosition);
                    }
                    else
                    {
                        bool isIncreasingPositionQuantity = (newQuantity > foundPosition.Quantity);

                        int quantitySum = foundPosition.Quantity + position.Quantity;
                        double newAveragePrice = foundPosition.AveragePrice;

                        if (isIncreasingPositionQuantity)
                        {
                            newAveragePrice = ((foundPosition.AveragePrice * foundPosition.Quantity) + (position.AveragePrice * position.Quantity)) / quantitySum;
                        }

                        double tickSize = position.Instrument.MasterInstrument.TickSize;
                        int ticksPerPoint = RealInstrumentService.GetTicksPerPoint(tickSize);

                        foundPosition.AveragePrice = newAveragePrice;

                        foundPosition.ModifyDate = position.CreateDate;
                        foundPosition.Quantity = newQuantity;
                        foundPosition.MarketPosition = newMarketPosition;

                        positionQuantity = newQuantity;
                    }
                }
                else if (position != null && position.Instrument != null)
                {
                    realPositions.Add(position);
                    positionQuantity = position.Quantity;
                }
            }

            return positionQuantity;
        }

        public void LoadPositions(Account account)
        {
            lock (realPositionLock)
            {
                lock (account.Positions)
                {
                    realPositions.Clear();

                    foreach (Position positionItem in account.Positions)
                    {
                        RealPosition position = BuildRealPosition(account,
                            positionItem.Instrument,
                            positionItem.MarketPosition,
                            positionItem.Quantity,
                            positionItem.AveragePrice,
                            GetDateTimeNow());

                        AddOrUpdatePosition(position);
                    }
                }
            }
        }
    }
}
