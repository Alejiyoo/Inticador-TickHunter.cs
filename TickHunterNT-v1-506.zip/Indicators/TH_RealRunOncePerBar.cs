﻿using System;


namespace NinjaTrader.NinjaScript.Indicators.TickHunterTA
{
    public class RealRunOncePerBar
    {
        private bool isNewBar = false;

        public bool IsFirstRunThisBar
        {
            get
            {
                return isNewBar;
            }
        }

        public void SetRunCompletedThisBar()
        {
            isNewBar = false;
        }

        public void SetNewBar()
        {
            isNewBar = true;
        }
    }
}
